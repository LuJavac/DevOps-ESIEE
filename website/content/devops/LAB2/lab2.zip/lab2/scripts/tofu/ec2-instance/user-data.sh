#!/usr/bin/env bash
nohup node /home/ec2-user/app.js &